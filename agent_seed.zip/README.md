# Literature Review Agent — Initial Fixtures

Files:

- `paper_analysis_schema.json` — canonical structured output schema.
- `paper_analysis_prompt.md` — analysis prompt for the detailed paper-analysis stage.
- `research_profile.yaml` — initial synthetic ML systems / LLM serving research direction.
- `fixture_papers.json` — seed relevance fixture.

The fixture intentionally contains placeholder IDs for OpScale, ThunderAgent and
H-MAS. These should be resolved to canonical arXiv/DOI metadata before the fixture
is used as an automated evaluation corpus. Do not silently guess identifiers.
